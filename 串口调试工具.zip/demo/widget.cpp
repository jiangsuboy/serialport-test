#include "widget.h"
#include "ui_widget.h"
#include "QMessageBox"
#include "unistd.h"
#include "qstring.h"
#include "QStack"
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{

    ui->setupUi(this);
    this->setWindowTitle("串口调试工具");
    this->getSerialRates();
    this->getSerialPort();
    this->ui->comboBox_3->addItem("1位");
     this->ui->comboBox_3->addItem("1.5位");
    this->ui->comboBox_3->addItem("2位");
    this->ui->comboBox_4->addItem("奇校验");
    this->ui->comboBox_4->addItem("偶校验");
    this->ui->comboBox_4->addItem("无校验");
    this->ui->comboBox_5->addItem("5位");
    this->ui->comboBox_5->addItem("6位");
    this->ui->comboBox_5->addItem("7位");
    this->ui->comboBox_5->addItem("8位");

    this->ui->comboBox_6->addItem("无数据流控制");
    this->ui->comboBox_6->addItem("硬件控制");
    this->ui->comboBox_6->addItem("软件控制");
    connect(this->ui->pushButton,SIGNAL(clicked()),this,SLOT(refresh()));
    connect(this->ui->pushButton_2,SIGNAL(clicked()),this,SLOT(serialPortConnect()));

    connect(this->ui->pushButton_3,SIGNAL(clicked()),this,SLOT(serialPortClose()));
    connect(this->ui->pushButton_4,SIGNAL(clicked()),this,SLOT(send()));

    this->port=new QSerialPort();

}

Widget::~Widget()
{
    delete ui;
}

void Widget::getSerialRates()
{

    this->ui->comboBox->addItem("1200");
    this->ui->comboBox->addItem("2400");
    this->ui->comboBox->addItem("4800");
    this->ui->comboBox->addItem("9600");
    this->ui->comboBox->addItem("19200");
    this->ui->comboBox->addItem("38400");
    this->ui->comboBox->addItem("57600");
    this->ui->comboBox->addItem("115200");


}

void Widget::getSerialPort()
{
    QList<QSerialPortInfo> list= QSerialPortInfo::availablePorts();

    for (int var = 0; var < list.length(); ++var) {
        QSerialPortInfo qserial=list.value(var);
        this->ui->comboBox_2->addItem(qserial.portName());
    }
}

void Widget::refresh()
{
    this->getSerialPort();
    this->getSerialRates();
}

void Widget::serialPortConnect()
{

    if(this->ui->comboBox_2->currentText().compare("")==0)
    {
        QMessageBox::information(this,"提醒","当前串口为空,请连接外设检查");
        return ;
    }
    qDebug()<< this->ui->comboBox->currentText();
    qDebug()<< this->ui->comboBox_2->currentText();
    qDebug()<<this->ui->comboBox_3->currentText();
    qDebug()<<this->ui->comboBox_4->currentText();
    qDebug()<< this->ui->comboBox_5->currentText();
    qDebug()<< this->ui->comboBox_6->currentText();

    QList<QSerialPortInfo> list= QSerialPortInfo::availablePorts();

    for (int var = 0; var < list.length(); ++var) {
        QSerialPortInfo qserial=list.value(var);
        if(qserial.portName().compare(this->ui->comboBox_2->currentText())==0)
        {
            this->port->setPort(qserial);
            connect(this->port,SIGNAL(readyRead()),this,SLOT(read()));
            break;
        }

    }
    if(this->ui->comboBox->currentText().compare("1200")==0)
        this->port->setBaudRate(QSerialPort::Baud1200);
    if(this->ui->comboBox->currentText().compare("2400")==0)
        this->port->setBaudRate(QSerialPort::Baud2400);
    if(this->ui->comboBox->currentText().compare("4800")==0)
        this->port->setBaudRate(QSerialPort::Baud4800);
    if(this->ui->comboBox->currentText().compare("9600")==0)
        this->port->setBaudRate(QSerialPort::Baud9600);
    if(this->ui->comboBox->currentText().compare("19200")==0)
        this->port->setBaudRate(QSerialPort::Baud19200);
    if(this->ui->comboBox->currentText().compare("38400")==0)
        this->port->setBaudRate(QSerialPort::Baud38400);
    if(this->ui->comboBox->currentText().compare("57600")==0)
        this->port->setBaudRate(QSerialPort::Baud57600);
    if(this->ui->comboBox->currentText().compare("115200")==0)
        this->port->setBaudRate(QSerialPort::Baud115200);


    if(this->ui->comboBox->currentText().compare("115200")==0)
        this->port->setBaudRate(QSerialPort::Baud115200);

    if(this->ui->comboBox_4->currentText().compare("奇校验")==0)
    this->port->setParity(QSerialPort::OddParity);
    if(this->ui->comboBox_4->currentText().compare("偶校验")==0)
    this->port->setParity(QSerialPort::EvenParity);
    if(this->ui->comboBox_4->currentText().compare("无校验")==0)
    this->port->setParity(QSerialPort::NoParity);


    if(this->ui->comboBox_5->currentText().compare("5位")==0)
    this->port->setDataBits(QSerialPort::Data5);
    if(this->ui->comboBox_5->currentText().compare("6位")==0)
    this->port->setDataBits(QSerialPort::Data6);
    if(this->ui->comboBox_5->currentText().compare("7位")==0)
    this->port->setDataBits(QSerialPort::Data7);
    if(this->ui->comboBox_5->currentText().compare("8位")==0)
    this->port->setDataBits(QSerialPort::Data8);

    if(this->ui->comboBox_3->currentText().compare("1位")==0)
    this->port->setStopBits(QSerialPort::OneStop);
    if(this->ui->comboBox_3->currentText().compare("1.5位")==0)
    this->port->setStopBits(QSerialPort::OneAndHalfStop);
    if(this->ui->comboBox_3->currentText().compare("2位")==0)
    this->port->setStopBits(QSerialPort::TwoStop);

    if(this->ui->comboBox_6->currentText().compare("无数据流控制")==0)
    this->port->setFlowControl(QSerialPort::NoFlowControl);

    if(this->ui->comboBox_6->currentText().compare("硬件控制")==0)
    this->port->setFlowControl(QSerialPort::HardwareControl);
    if(this->ui->comboBox_6->currentText().compare("软件控制")==0)
    this->port->setFlowControl(QSerialPort::SoftwareControl);

    this->port->open(QIODevice::ReadWrite);
    this->ui->comboBox->setEditable(false);
    this->ui->comboBox_2->setEditable(false);
    this->ui->comboBox_3->setEditable(false);
    this->ui->comboBox_4->setEditable(false);
    this->ui->comboBox_5->setEditable(false);
    this->ui->comboBox_6->setEditable(false);

    this->ui->comboBox->setEnabled(false);
    this->ui->comboBox_3->setEnabled(false);
    this->ui->comboBox_2->setEnabled(false);
    this->ui->comboBox_4->setEnabled(false);
    this->ui->comboBox_5->setEnabled(false);
    this->ui->comboBox_6->setEnabled(false);




}

void Widget::send()
{
    char* data=this->ui->textEdit_2->toPlainText().append('\r').append('\n').toLocal8Bit().data();
    qDebug()<<data;

    this->port->write(data);


}

void Widget::serialPortClose()
{
    this->ui->comboBox->setEnabled(true);
    this->ui->comboBox_2->setEnabled(true);
    this->ui->comboBox_3->setEnabled(true);
    this->ui->comboBox_4->setEnabled(true);
    this->ui->comboBox_5->setEnabled(true);
    this->ui->comboBox_6->setEnabled(true);

    this->port->close();
}

void Widget::read()
{

    QString string(this->port->readAll());
    qDebug()<<string.toLocal8Bit();
    this->ui->textEdit->append(string.toLocal8Bit());
}







